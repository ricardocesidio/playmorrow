import {
  Body,
  Controller,
  DefaultValuePipe,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  NotFoundException,
  Param,
  ParseBoolPipe,
  ParseIntPipe,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiCreatedResponse, ApiOkResponse, ApiQuery, ApiTags } from '@nestjs/swagger';

import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { SessionAuthGuard } from '../auth/guards/session-auth.guard';
import { OptionalSessionGuard } from '../auth/guards/optional-session.guard';
import { EventBus } from '../common/event-bus';
import { CreateDevlogDto } from './dto/create-devlog.dto';
import { UpdateDevlogDto } from './dto/update-devlog.dto';
import { DevlogsService } from './devlogs.service';

@ApiTags('devlogs')
@Controller()
export class DevlogsController {
  constructor(
    private readonly devlogsService: DevlogsService,
    private readonly eventBus: EventBus,
  ) {}

  @Post('games/:gameSlug/devlogs')
  @UseGuards(SessionAuthGuard)
  @ApiCreatedResponse({ description: 'Devlog created.' })
  async create(
    @CurrentUser() user: { id: string },
    @Param('gameSlug') gameSlug: string,
    @Body() dto: CreateDevlogDto,
  ) {
    const result = await this.devlogsService.create(user.id, gameSlug, dto);
    if (dto.isPublished || dto.status === 'PUBLISHED') {
      this.eventBus.emit({ type: 'devlog_published', actorId: user.id, gameId: result.game?.id, targetType: 'DEVLOG', targetId: result.id, studioId: result.studio?.id, metadata: { title: result.title } });
    }
    return result;
  }

  @Get('games/:gameSlug/devlogs')
  @UseGuards(OptionalSessionGuard)
  @ApiOkResponse({ description: 'Paginated devlogs for a game.' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'pageSize', required: false })
  @ApiQuery({ name: 'includeDrafts', required: false })
  async findByGame(
    @Param('gameSlug') gameSlug: string,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('pageSize', new DefaultValuePipe(20), ParseIntPipe) pageSize: number,
    @Query('includeDrafts', new DefaultValuePipe(false), ParseBoolPipe) includeDrafts: boolean,
    @CurrentUser() user?: { id: string },
  ) {
    return this.devlogsService.findByGameSlug(gameSlug, page, Math.min(pageSize, 100), includeDrafts, user?.id);
  }

  @Get('devlogs')
  @ApiOkResponse({ description: 'Paginated list of published devlogs.' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'pageSize', required: false })
  @ApiQuery({ name: 'search', required: false })
  async findAll(
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('pageSize', new DefaultValuePipe(20), ParseIntPipe) pageSize: number,
    @Query('search') search?: string,
  ) {
    return this.devlogsService.findAllPublished(page, Math.min(pageSize, 100), search);
  }

  @Get('devlogs/:id')
  @UseGuards(OptionalSessionGuard)
  @ApiOkResponse({ description: 'Devlog detail.' })
  async findById(@Param('id') id: string, @CurrentUser() user?: { id: string }) {
    const devlog = await this.devlogsService.findById(id, user?.id);
    if (!devlog) {
      throw new NotFoundException('Devlog not found');
    }
    return devlog;
  }

  @Patch('devlogs/:id')
  @UseGuards(SessionAuthGuard)
  @ApiOkResponse({ description: 'Devlog updated.' })
  async update(
    @CurrentUser() user: { id: string },
    @Param('id') id: string,
    @Body() dto: UpdateDevlogDto,
  ) {
    return this.devlogsService.update(user.id, id, dto);
  }

  @Delete('devlogs/:id')
  @UseGuards(SessionAuthGuard)
  @HttpCode(HttpStatus.OK)
  @ApiOkResponse({ description: 'Devlog deleted (cascades to comments, reactions).' })
  async remove(@CurrentUser() user: { id: string }, @Param('id') id: string) {
    return this.devlogsService.remove(user.id, id);
  }

  @Get('me/devlogs')
  @UseGuards(SessionAuthGuard)
  @ApiOkResponse({ description: "Current user's devlogs (all studios/games)." })
  async findMyDevlogs(@CurrentUser() user: { id: string }) {
    return this.devlogsService.findAllByAuthorId(user.id);
  }

  @Post('devlogs/:id/like')
  @UseGuards(SessionAuthGuard)
  @HttpCode(HttpStatus.OK)
  async toggleLike(@CurrentUser() user: { id: string }, @Param('id') id: string) {
    return this.devlogsService.toggleLike(user.id, id);
  }
}
