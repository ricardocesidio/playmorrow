import { Module } from '@nestjs/common';

import { PrismaModule } from '../prisma/prisma.module';
import { AuthModule } from '../auth/auth.module';
import { AuditLogModule } from '../audit-log/audit-log.module';
import { FeedModule } from '../feed/feed.module';
import { PressKitsController } from './press-kits.controller';
import { PressKitsService } from './press-kits.service';

@Module({
  imports: [PrismaModule, AuthModule, AuditLogModule, FeedModule],
  controllers: [PressKitsController],
  providers: [PressKitsService],
})
/** Game-level press kits */
export class PressKitsModule {}
