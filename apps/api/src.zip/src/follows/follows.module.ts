import { Module } from '@nestjs/common';

import { AnalyticsModule } from '../analytics/analytics.module';
import { AuthModule } from '../auth/auth.module';
import { GamesModule } from '../games/games.module';
import { PlayerXpModule } from '../player-xp/player-xp.module';
import { PrismaModule } from '../prisma/prisma.module';
import { StudiosModule } from '../studios/studios.module';
import { FollowsController } from './follows.controller';
import { FollowsService } from './follows.service';
import { CountersService } from '../common/counters.service';

@Module({
  imports: [PrismaModule, AuthModule, GamesModule, StudiosModule, PlayerXpModule, AnalyticsModule],
  controllers: [FollowsController],
  providers: [FollowsService, CountersService],
})
export class FollowsModule {}
