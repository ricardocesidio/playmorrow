import {
  Controller,
  DefaultValuePipe,
  Get,
  ParseIntPipe,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiOkResponse, ApiQuery, ApiTags } from '@nestjs/swagger';

import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { SessionAuthGuard } from '../auth/guards/session-auth.guard';
import { FeedService, type FeedResult } from './feed.service';

@ApiTags('feed')
@Controller()
export class FeedController {
  constructor(private readonly feedService: FeedService) {}

  @Get('me/feed')
  @UseGuards(SessionAuthGuard)
  @ApiOkResponse({ description: 'Personalized feed for current user. Use cursor for complete pagination.' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'pageSize', required: false })
  @ApiQuery({ name: 'type', required: false, enum: ['all', 'devlogs', 'roadmap'] })
  async getPersonalFeed(
    @CurrentUser() user: { id: string },
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('pageSize', new DefaultValuePipe(20), ParseIntPipe) pageSize: number,
    @Query('type', new DefaultValuePipe('all')) type: 'all' | 'devlogs' | 'roadmap',
  ): Promise<FeedResult> {
    return this.feedService.getPersonalFeed(user.id, page, pageSize, type);
  }

  @Get('me/feed/cursor')
  @UseGuards(SessionAuthGuard)
  @ApiOkResponse({ description: 'Cursor-based feed pagination — no cap, all data reachable.' })
  @ApiQuery({ name: 'cursor', required: false, description: 'JSON: {"createdAt":"ISO","id":"string"}' })
  @ApiQuery({ name: 'pageSize', required: false })
  @ApiQuery({ name: 'type', required: false, enum: ['all', 'devlogs', 'roadmap'] })
  async getPersonalFeedCursor(
    @CurrentUser() user: { id: string },
    @Query('cursor') cursorRaw: string | undefined,
    @Query('pageSize', new DefaultValuePipe(20), ParseIntPipe) pageSize: number,
    @Query('type', new DefaultValuePipe('all')) type: 'all' | 'devlogs' | 'roadmap',
  ): Promise<FeedResult> {
    let cursor: { createdAt: string; id: string } | null = null;
    if (cursorRaw) {
      try { cursor = JSON.parse(cursorRaw); } catch { /* invalid cursor — start from top */ }
    }
    return this.feedService.getPersonalFeedCursor(user.id, pageSize, type, cursor);
  }

  @Get('feed/public')
  @ApiOkResponse({ description: 'Public feed of latest content.' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'pageSize', required: false })
  @ApiQuery({ name: 'type', required: false, enum: ['all', 'devlogs', 'roadmap'] })
  async getPublicFeed(
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('pageSize', new DefaultValuePipe(20), ParseIntPipe) pageSize: number,
    @Query('type', new DefaultValuePipe('all')) type: 'all' | 'devlogs' | 'roadmap',
  ): Promise<FeedResult> {
    return this.feedService.getPublicFeed(page, pageSize, type);
  }

  @Get('feed/events')
  @ApiOkResponse({ description: 'Paginated feed events.' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'pageSize', required: false })
  async getFeedEvents(
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('pageSize', new DefaultValuePipe(20), ParseIntPipe) pageSize: number,
  ): Promise<{ items: unknown[]; total: number; page: number; pageSize: number; hasMore: boolean }> {
    return this.feedService.getFeedEvents(page, pageSize);
  }
}
