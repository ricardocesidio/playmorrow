import { Injectable, Logger } from '@nestjs/common';
import type { Prisma } from '@playmorrow/database';

import { PrismaService } from '../prisma/prisma.service';

interface FeedItem {
  id: string;
  type: 'DEVLOG' | 'ROADMAP_ITEM';
  createdAt: string;
  publishedAt: string | null;
  title: string;
  summary: string;
  status?: string;
  targetDate?: string | null;
  game: { id: string; title: string; slug: string; coverUrl: string | null };
  studio: { id: string; name: string; slug: string; logoUrl: string | null };
  target: { kind: 'DEVLOG' | 'ROADMAP_ITEM'; id: string };
}

export interface FeedResult {
  items: FeedItem[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
  truncated: boolean;
  nextCursor?: { createdAt: string; id: string } | null;
}

const DEVLOG_FEED_INCLUDE = {
  game: {
    select: { id: true, title: true, slug: true, coverUrl: true, studioId: true },
  },
} satisfies Prisma.DevlogInclude;

const ROADMAP_FEED_INCLUDE = {
  game: {
    select: { id: true, title: true, slug: true, coverUrl: true, studioId: true },
  },
} satisfies Prisma.RoadmapItemInclude;

@Injectable()
export class FeedService {
  private readonly logger = new Logger(FeedService.name);

  constructor(private readonly prisma: PrismaService) {}

  async getPersonalFeed(
    userId: string,
    page: number,
    pageSize: number,
    type: 'all' | 'devlogs' | 'roadmap',
  ): Promise<FeedResult> {
    const cappedSize = Math.min(pageSize, 50);

    // Resolve followed studio IDs and game IDs
    const follows = await this.prisma.follow.findMany({
      where: { userId },
      select: { targetType: true, studioId: true, gameId: true },
    });

    const followedStudioIds = follows
      .filter((f) => f.targetType === 'STUDIO' && f.studioId)
      .map((f) => f.studioId!);

    const followedGameIds = follows
      .filter((f) => f.targetType === 'GAME' && f.gameId)
      .map((f) => f.gameId!);

    // Find games belonging to followed studios
    const studioGames = followedStudioIds.length > 0
      ? await this.prisma.game.findMany({
          where: { studioId: { in: followedStudioIds } },
          select: { id: true },
        })
      : [];

    const allGameIds = new Set([
      ...followedGameIds,
      ...studioGames.map((g) => g.id),
    ]);

    if (allGameIds.size === 0) {
      return { items: [], total: 0, page, pageSize: cappedSize, hasMore: false, truncated: false };
    }

    const gameIdArray = Array.from(allGameIds);

    if (gameIdArray.length === 0) {
      return { items: [], total: 0, page, pageSize: cappedSize, hasMore: false, truncated: false };
    }

    // Count actual data per type (cheap count queries) for proportional limit allocation
    const [devlogTotal, roadmapTotal] = await Promise.all([
      type !== 'roadmap'
        ? this.prisma.devlog.count({ where: { gameId: { in: gameIdArray }, isPublished: true } })
        : Promise.resolve(0),
      type !== 'devlogs'
        ? this.prisma.roadmapItem.count({ where: { gameId: { in: gameIdArray } } })
        : Promise.resolve(0),
    ]);

    // Per-type cap: allocate the pool budget proportionally, ensure minority type has room
    const basePerTypeLimit = Math.min((page + 1) * cappedSize * 2, 500);
    const devlogLimit = type === 'roadmap' ? 0 : Math.min(basePerTypeLimit, Math.max(devlogTotal || 50, 50));
    const roadmapLimit = type === 'devlogs' ? 0 : Math.min(basePerTypeLimit, Math.max(roadmapTotal || 50, 50));

    const [devlogs, roadmapItems] = await Promise.all([
      type !== 'roadmap'
        ? this.prisma.devlog.findMany({
            where: { gameId: { in: gameIdArray }, isPublished: true },
            include: DEVLOG_FEED_INCLUDE,
            orderBy: { publishedAt: 'desc' },
            take: devlogLimit,
          })
        : Promise.resolve([]),
      type !== 'devlogs'
        ? this.prisma.roadmapItem.findMany({
            where: { gameId: { in: gameIdArray } },
            include: ROADMAP_FEED_INCLUDE,
            orderBy: { updatedAt: 'desc' },
            take: roadmapLimit,
          })
        : Promise.resolve([]),
    ]);

    if (devlogs.length >= devlogLimit) {
      this.logger.warn({ devlogLimit, devlogTotal }, 'Feed devlog cap reached — data may be truncated');
    }
    if (roadmapItems.length >= roadmapLimit) {
      this.logger.warn({ roadmapLimit, roadmapTotal }, 'Feed roadmap cap reached — data may be truncated');
    }

    // Resolve studio info for all unique game IDs
    const gameIds = new Set<string>();
    for (const d of devlogs) gameIds.add(d.gameId);
    for (const r of roadmapItems) gameIds.add(r.gameId);

    const gamesWithStudio = gameIds.size > 0
      ? await this.prisma.game.findMany({
          where: { id: { in: Array.from(gameIds) } },
          select: { id: true, studio: { select: { id: true, name: true, slug: true, logoUrl: true } } },
        })
      : [];
    const studioMap = new Map(gamesWithStudio.map((g) => [g.id, g.studio]));

    // Build feed items
    const feedItems: FeedItem[] = [];

    for (const d of devlogs) {
      const studio = studioMap.get(d.gameId);
      feedItems.push({
        id: d.id,
        type: 'DEVLOG',
        createdAt: d.createdAt.toISOString(),
        publishedAt: d.publishedAt?.toISOString() ?? null,
        title: d.title,
        summary: d.body.length > 200 ? `${d.body.slice(0, 200)}...` : d.body,
        game: { id: d.game.id, title: d.game.title, slug: d.game.slug, coverUrl: d.game.coverUrl },
        studio: studio ?? { id: d.game.studioId, name: '', slug: '', logoUrl: null },
        target: { kind: 'DEVLOG', id: d.id },
      });
    }

    for (const r of roadmapItems) {
      const studio = studioMap.get(r.gameId);
      feedItems.push({
        id: r.id,
        type: 'ROADMAP_ITEM',
        createdAt: r.createdAt.toISOString(),
        publishedAt: null,
        title: r.title,
        summary: r.description ?? '',
        status: r.status,
        targetDate: r.targetDate?.toISOString() ?? null,
        game: { id: r.game.id, title: r.game.title, slug: r.game.slug, coverUrl: r.game.coverUrl },
        studio: studio ?? { id: r.game.studioId, name: '', slug: '', logoUrl: null },
        target: { kind: 'ROADMAP_ITEM', id: r.id },
      });
    }

    // Sort: use publishedAt for devlogs, updatedAt for roadmap (but we don't have updatedAt in the query)
    // Better to use createdAt as the common sort key
    feedItems.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const total = feedItems.length;
    const start = (page - 1) * cappedSize;
    const paged = feedItems.slice(start, start + cappedSize);

    const truncated =
      (type === 'all' || type === 'devlogs') && devlogs.length >= devlogLimit
      || (type === 'all' || type === 'roadmap') && roadmapItems.length >= roadmapLimit;

    return {
      items: paged,
      total,
      page,
      pageSize: cappedSize,
      hasMore: start + cappedSize < total,
      truncated,
    };
  }

  /**
   * Cursor-based feed pagination — busca infinita sem perda de dados.
   * Aceita um cursor { createdAt, id } e retorna os próximos pageSize items.
   * Quando cursor é null, retorna os items mais recentes (primeira página).
   */
  async getPersonalFeedCursor(
    userId: string,
    pageSize: number,
    type: 'all' | 'devlogs' | 'roadmap',
    cursor?: { createdAt: string; id: string } | null,
  ): Promise<FeedResult> {
    const cappedSize = Math.min(pageSize, 50);

    // Resolve followed studio IDs and game IDs
    const follows = await this.prisma.follow.findMany({
      where: { userId },
      select: { targetType: true, studioId: true, gameId: true },
    });

    const followedStudioIds = follows
      .filter((f) => f.targetType === 'STUDIO' && f.studioId)
      .map((f) => f.studioId!);

    const followedGameIds = follows
      .filter((f) => f.targetType === 'GAME' && f.gameId)
      .map((f) => f.gameId!);

    const studioGames = followedStudioIds.length > 0
      ? await this.prisma.game.findMany({
          where: { studioId: { in: followedStudioIds } },
          select: { id: true },
        })
      : [];

    const allGameIds = new Set([
      ...followedGameIds,
      ...studioGames.map((g) => g.id),
    ]);

    if (allGameIds.size === 0) {
      return { items: [], total: 0, page: 1, pageSize: cappedSize, hasMore: false, truncated: false, nextCursor: null };
    }

    const gameIdArray = Array.from(allGameIds);
    const limit = cappedSize + 1;

    // Build where clause: se cursor existe, busca items ANTES dele
    const buildWhere = (prefix: string) => {
      const base = prefix === 'devlogs'
        ? { gameId: { in: gameIdArray }, isPublished: true }
        : { gameId: { in: gameIdArray } };
      if (!cursor) return base;
      return {
        ...base,
        OR: [
          { createdAt: { lt: new Date(cursor.createdAt) } },
          { createdAt: new Date(cursor.createdAt), id: { lt: cursor.id } },
        ],
      } as any;
    };

    const [devlogs, roadmapItems] = await Promise.all([
      type !== 'roadmap'
        ? this.prisma.devlog.findMany({
            where: buildWhere('devlogs'),
            include: DEVLOG_FEED_INCLUDE,
            orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
            take: limit,
          })
        : Promise.resolve([]),
      type !== 'devlogs'
        ? this.prisma.roadmapItem.findMany({
            where: buildWhere('roadmap'),
            include: ROADMAP_FEED_INCLUDE,
            orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
            take: limit,
          })
        : Promise.resolve([]),
    ]);

    // Resolve studio info
    const gameIdSet = new Set<string>();
    for (const d of devlogs) gameIdSet.add(d.gameId);
    for (const r of roadmapItems) gameIdSet.add(r.gameId);

    const gamesWithStudio = gameIdSet.size > 0
      ? await this.prisma.game.findMany({
          where: { id: { in: Array.from(gameIdSet) } },
          select: { id: true, studio: { select: { id: true, name: true, slug: true, logoUrl: true } } },
        })
      : [];
    const studioMap = new Map(gamesWithStudio.map((g) => [g.id, g.studio]));

    // Build + merge + sort (small — at most 2*(pageSize+1) items)
    const merged: FeedItem[] = [];

    for (const d of devlogs) {
      const studio = studioMap.get(d.gameId);
      merged.push({
        id: d.id, type: 'DEVLOG', createdAt: d.createdAt.toISOString(),
        publishedAt: d.publishedAt?.toISOString() ?? null,
        title: d.title, summary: d.body.length > 200 ? `${d.body.slice(0, 200)}...` : d.body,
        game: { id: d.game.id, title: d.game.title, slug: d.game.slug, coverUrl: d.game.coverUrl },
        studio: studio ?? { id: d.game.studioId, name: '', slug: '', logoUrl: null },
        target: { kind: 'DEVLOG', id: d.id },
      });
    }
    for (const r of roadmapItems) {
      const studio = studioMap.get(r.gameId);
      merged.push({
        id: r.id, type: 'ROADMAP_ITEM', createdAt: r.createdAt.toISOString(),
        publishedAt: null, title: r.title, summary: r.description ?? '',
        status: r.status, targetDate: r.targetDate?.toISOString() ?? null,
        game: { id: r.game.id, title: r.game.title, slug: r.game.slug, coverUrl: r.game.coverUrl },
        studio: studio ?? { id: r.game.studioId, name: '', slug: '', logoUrl: null },
        target: { kind: 'ROADMAP_ITEM', id: r.id },
      });
    }

    merged.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const hasMore = merged.length > cappedSize;
    const items = merged.slice(0, cappedSize);
    const lastItem = items[items.length - 1];
    const nextCursor = hasMore && lastItem
      ? { createdAt: lastItem.createdAt, id: lastItem.id }
      : null;

    return {
      items, total: 0, page: 1, pageSize: cappedSize,
      hasMore, truncated: false, nextCursor,
    };
  }

  async getPublicFeed(
    page: number,
    pageSize: number,
    type: 'all' | 'devlogs' | 'roadmap',
  ): Promise<FeedResult> {
    const cappedSize = Math.min(pageSize, 50);

    const [devlogs, roadmapItems] = await Promise.all([
      type !== 'roadmap'
        ? this.prisma.devlog.findMany({
            where: { isPublished: true },
            include: DEVLOG_FEED_INCLUDE,
            orderBy: { publishedAt: 'desc' },
            take: type === 'all' ? cappedSize * 2 : cappedSize,
          })
        : Promise.resolve([]),
      type !== 'devlogs'
        ? this.prisma.roadmapItem.findMany({
            include: ROADMAP_FEED_INCLUDE,
            orderBy: { updatedAt: 'desc' },
            take: type === 'all' ? cappedSize * 2 : cappedSize,
          })
        : Promise.resolve([]),
    ]);

    // Resolve studio info
    const gameIds = new Set<string>();
    for (const d of devlogs) gameIds.add(d.gameId);
    for (const r of roadmapItems) gameIds.add(r.gameId);

    const gamesWithStudio = gameIds.size > 0
      ? await this.prisma.game.findMany({
          where: { id: { in: Array.from(gameIds) } },
          select: { id: true, studio: { select: { id: true, name: true, slug: true, logoUrl: true } } },
        })
      : [];
    const studioMap = new Map(gamesWithStudio.map((g) => [g.id, g.studio]));

    const feedItems: FeedItem[] = [];

    for (const d of devlogs) {
      const studio = studioMap.get(d.gameId);
      feedItems.push({
        id: d.id,
        type: 'DEVLOG',
        createdAt: d.createdAt.toISOString(),
        publishedAt: d.publishedAt?.toISOString() ?? null,
        title: d.title,
        summary: d.body.length > 200 ? `${d.body.slice(0, 200)}...` : d.body,
        game: { id: d.game.id, title: d.game.title, slug: d.game.slug, coverUrl: d.game.coverUrl },
        studio: studio ?? { id: d.game.studioId, name: '', slug: '', logoUrl: null },
        target: { kind: 'DEVLOG', id: d.id },
      });
    }

    for (const r of roadmapItems) {
      const studio = studioMap.get(r.gameId);
      feedItems.push({
        id: r.id,
        type: 'ROADMAP_ITEM',
        createdAt: r.createdAt.toISOString(),
        publishedAt: null,
        title: r.title,
        summary: r.description ?? '',
        status: r.status,
        targetDate: r.targetDate?.toISOString() ?? null,
        game: { id: r.game.id, title: r.game.title, slug: r.game.slug, coverUrl: r.game.coverUrl },
        studio: studio ?? { id: r.game.studioId, name: '', slug: '', logoUrl: null },
        target: { kind: 'ROADMAP_ITEM', id: r.id },
      });
    }

    feedItems.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const total = feedItems.length;
    const start = (page - 1) * cappedSize;
    const paged = feedItems.slice(start, start + cappedSize);

    const perTypeTake = type === 'all' ? cappedSize * 2 : cappedSize;
    const truncated =
      (type === 'all' || type === 'devlogs') && devlogs.length >= perTypeTake
      || (type === 'all' || type === 'roadmap') && roadmapItems.length >= perTypeTake;

    return {
      items: paged,
      total,
      page,
      pageSize: cappedSize,
      hasMore: start + cappedSize < total,
      truncated,
    };
  }

  async getFeedEvents(page = 1, pageSize = 20) {
    const skip = (page - 1) * pageSize;
    const [items, total] = await Promise.all([
      this.prisma.feedEvent.findMany({
        orderBy: { createdAt: 'desc' },
        skip,
        take: pageSize,
      }),
      this.prisma.feedEvent.count(),
    ]);
    return { items, total, page, pageSize, hasMore: skip + pageSize < total };
  }
}
